package com.chatapp.client;

import com.chatapp.model.Message;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Color;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ChatWindow extends JFrame {

    private final int userId;
    private final String username;
    private final String fullname;
    private final LoginWindow.ServerConnection.ClientSession session;
    private final JTextArea conversationArea = new JTextArea();
    private final JTextField messageField = new JTextField();
    private final JButton sendButton = new JButton("Gửi");
    private final JTextField searchField = new JTextField(18);
    private final JButton searchButton = new JButton("Tìm tin nhắn");
    private final Map<Integer, String> displayedMessages = new LinkedHashMap<>();
    private final List<Message> searchResults = new ArrayList<>();
    private volatile boolean searchInProgress;
    private boolean historyLoading = true;

    public ChatWindow(int userId, String username, String fullname,
                      LoginWindow.ServerConnection.ClientSession session) {
        super("Chat Online - Phòng chung");
        LoginWindow.configureTheme();
        getContentPane().setBackground(LoginWindow.BACKGROUND);
        this.userId = userId;
        this.username = username;
        this.fullname = fullname;
        this.session = session;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(620, 460));
        setLayout(new BorderLayout(0, 12));
        add(createHeader(), BorderLayout.NORTH);
        add(createConversationArea(), BorderLayout.CENTER);
        add(createComposer(), BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);

        sendButton.addActionListener(event -> sendMessage());
        messageField.addActionListener(event -> sendMessage());
        searchButton.addActionListener(event -> searchMessages());
        searchField.addActionListener(event -> searchMessages());
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent event) {
                session.close();
            }
        });
        startReceivingMessages();
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout(0, 8));
        header.setBackground(LoginWindow.BACKGROUND);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(LoginWindow.SURFACE);
        panel.setBorder(BorderFactory.createEmptyBorder(16, 18, 4, 18));

        JLabel roomLabel = new JLabel("Phòng chat chung");
        roomLabel.setFont(roomLabel.getFont().deriveFont(Font.BOLD, 20f));
        roomLabel.setForeground(LoginWindow.ACCENT);
        panel.add(roomLabel, BorderLayout.WEST);

        JPanel accountPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        accountPanel.setBackground(LoginWindow.SURFACE);
        accountPanel.add(new JLabel(fullname + " (" + username + ")"));
        accountPanel.getComponent(0).setForeground(LoginWindow.MUTED_TEXT);
        JButton logoutButton = new JButton("Đăng xuất");
        LoginWindow.styleButton(logoutButton, false);
        logoutButton.addActionListener(event -> logout());
        accountPanel.add(logoutButton);
        panel.add(accountPanel, BorderLayout.EAST);

        JPanel searchPanel = new JPanel(new BorderLayout(8, 0));
        searchPanel.setBackground(LoginWindow.SURFACE);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(8, 18, 10, 18));
        LoginWindow.styleInput(searchField);
        LoginWindow.styleButton(searchButton, false);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        header.add(panel, BorderLayout.NORTH);
        header.add(searchPanel, BorderLayout.SOUTH);
        return header;
    }

    private JScrollPane createConversationArea() {
        conversationArea.setEditable(false);
        conversationArea.setBackground(LoginWindow.INPUT_BACKGROUND);
        conversationArea.setForeground(LoginWindow.TEXT_COLOR);
        conversationArea.setCaretColor(LoginWindow.ACCENT);
        conversationArea.setSelectionColor(new Color(70, 115, 78));
        conversationArea.setLineWrap(true);
        conversationArea.setWrapStyleWord(true);
        conversationArea.setText("Đang tải lịch sử tin nhắn...\n");

        JScrollPane scrollPane = new JScrollPane(conversationArea);
        scrollPane.getViewport().setBackground(LoginWindow.INPUT_BACKGROUND);
        TitledBorder titleBorder = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(LoginWindow.BORDER_COLOR), "Tin nhắn");
        titleBorder.setTitleColor(LoginWindow.ACCENT);
        scrollPane.setBorder(titleBorder);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(0, 18, 0, 18), scrollPane.getBorder()));
        return scrollPane;
    }

    private JPanel createComposer() {
        JPanel panel = new JPanel(new BorderLayout(8, 0));
        panel.setBackground(LoginWindow.BACKGROUND);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 18, 18, 18));
        LoginWindow.styleInput(messageField);
        LoginWindow.styleButton(sendButton, true);
        panel.add(messageField, BorderLayout.CENTER);
        panel.add(sendButton, BorderLayout.EAST);
        return panel;
    }

    private void startReceivingMessages() {
        Thread receiver = new Thread(this::receiveMessages, "chat-message-receiver-" + userId);
        receiver.setDaemon(true);
        receiver.start();
    }

    private void receiveMessages() {
        try {
            String line;
            while ((line = session.readLine()) != null) {
                displayServerMessage(line);
            }
            showDisconnected("Server đã đóng kết nối.");
        } catch (IOException e) {
            showDisconnected("Mất kết nối tới server: " + e.getMessage());
        }
    }

    private void displayServerMessage(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length == 6 && "HISTORY".equals(parts[0])) {
            try {
                int messageId = Integer.parseInt(parts[1]);
                String senderFullname = LoginWindow.ServerConnection.decodeField(parts[3]);
                String content = LoginWindow.ServerConnection.decodeField(parts[4]);
                storeMessage(messageId, "[" + parts[5] + "] " + senderFullname + ": " + content);
            } catch (IllegalArgumentException e) {
                appendToConversation("[Server] Lịch sử có tin nhắn không đúng định dạng.");
            }
        } else if (parts.length == 2 && "HISTORY_END".equals(parts[0])) {
            try {
                finishHistory(Integer.parseInt(parts[1]));
            } catch (NumberFormatException e) {
                appendToConversation("[Server] Số lượng tin lịch sử không hợp lệ.");
            }
        } else if (parts.length == 6 && "MESSAGE".equals(parts[0])) {
            try {
                int messageId = Integer.parseInt(parts[1]);
                String senderFullname = LoginWindow.ServerConnection.decodeField(parts[3]);
                String content = LoginWindow.ServerConnection.decodeField(parts[4]);
                storeMessage(messageId, "[" + parts[5] + "] " + senderFullname + ": " + content);
            } catch (IllegalArgumentException e) {
                appendToConversation("[Server] Nhận được tin nhắn không đúng định dạng.");
            }
        } else if (parts.length == 6 && "MESSAGE_UPDATED".equals(parts[0])) {
            try {
                int messageId = Integer.parseInt(parts[1]);
                String senderFullname = LoginWindow.ServerConnection.decodeField(parts[3]);
                String content = LoginWindow.ServerConnection.decodeField(parts[4]);
                storeMessage(messageId, "[" + parts[5] + "] " + senderFullname
                        + ": " + content + " (đã sửa)");
            } catch (IllegalArgumentException e) {
                appendToConversation("[Server] Thông tin sửa tin nhắn không đúng định dạng.");
            }
        } else if (parts.length == 2 && "MESSAGE_DELETED".equals(parts[0])) {
            try {
                int messageId = Integer.parseInt(parts[1]);
                SwingUtilities.invokeLater(() -> {
                    displayedMessages.remove(messageId);
                    renderMessages();
                });
            } catch (NumberFormatException e) {
                appendToConversation("[Server] Mã tin nhắn bị xóa không hợp lệ.");
            }
        } else if (parts.length == 6 && "SEARCH_RESULT".equals(parts[0])) {
            try {
                Message result = new Message(
                        Integer.parseInt(parts[1]),
                        Integer.parseInt(parts[2]),
                        LoginWindow.ServerConnection.decodeField(parts[4]),
                        LocalDateTime.parse(parts[5], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                );
                result.setSenderFullname(LoginWindow.ServerConnection.decodeField(parts[3]));
                searchResults.add(result);
            } catch (RuntimeException e) {
                appendToConversation("[Server] Kết quả tìm kiếm không đúng định dạng.");
            }
        } else if (parts.length == 2 && "SEARCH_END".equals(parts[0])) {
            searchInProgress = false;
            SwingUtilities.invokeLater(() -> searchButton.setEnabled(true));
            showSearchResults(new ArrayList<>(searchResults));
        } else if ("ACCOUNT_BANNED".equals(line)) {
            appendToConversation("[Server] Tài khoản của bạn đã bị ban.");
            session.close();
            showDisconnected("Kết nối đã đóng.");
        } else if (parts.length == 2 && "ERR".equals(parts[0])) {
            try {
                appendToConversation("[Server] "
                        + LoginWindow.ServerConnection.decodeField(parts[1]));
            } catch (IllegalArgumentException e) {
                appendToConversation("[Server] Phản hồi lỗi không đúng định dạng.");
            }
        } else {
            appendToConversation("[Server] Nhận được dữ liệu không đúng định dạng.");
        }
    }

    private void appendToConversation(String message) {
        SwingUtilities.invokeLater(() -> conversationArea.append(message + "\n"));
    }

    private void storeMessage(int messageId, String message) {
        SwingUtilities.invokeLater(() -> {
            displayedMessages.put(messageId, message);
            historyLoading = false;
            renderMessages();
        });
    }

    private void renderMessages() {
        conversationArea.setText("");
        for (String message : displayedMessages.values()) {
            conversationArea.append(message + "\n");
        }
        conversationArea.setCaretPosition(conversationArea.getDocument().getLength());
    }

    private void finishHistory(int count) {
        SwingUtilities.invokeLater(() -> {
            if (historyLoading) {
                conversationArea.setText("");
                historyLoading = false;
            }
            if (count == 0) {
                conversationArea.append("Chưa có tin nhắn nào trong phòng chat.\n");
            }
        });
    }

    private void searchMessages() {
        String query = searchField.getText().trim();
        if (query.isEmpty() || searchInProgress) {
            return;
        }

        searchResults.clear();
        searchInProgress = true;
        searchButton.setEnabled(false);
        try {
            session.searchMessages(query);
        } catch (IOException e) {
            searchInProgress = false;
            searchButton.setEnabled(true);
            showDisconnected("Không thể tìm tin nhắn: " + e.getMessage());
        }
    }

    private void showSearchResults(List<Message> results) {
        SwingUtilities.invokeLater(() -> {
            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy tin nhắn phù hợp.",
                        "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            DefaultTableModel model = new DefaultTableModel(
                    new Object[]{"ID", "Người gửi", "Nội dung", "Thời gian"}, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            for (Message message : results) {
                model.addRow(new Object[]{message.getMessageId(), message.getSenderFullname(),
                        message.getContent(), message.getSentAt()});
            }

            JTable table = new JTable(model);
            table.setAutoCreateRowSorter(true);
            table.setFillsViewportHeight(true);
            table.setRowHeight(24);
            table.setBackground(LoginWindow.INPUT_BACKGROUND);
            table.setForeground(LoginWindow.TEXT_COLOR);
            table.setGridColor(LoginWindow.BORDER_COLOR);
            table.setSelectionBackground(new Color(58, 91, 64));
            table.getTableHeader().setBackground(LoginWindow.SURFACE);
            table.getTableHeader().setForeground(LoginWindow.ACCENT);

            JDialog dialog = new JDialog(this, "Kết quả tìm kiếm", true);
            dialog.setLayout(new BorderLayout(8, 8));
            dialog.add(new JScrollPane(table), BorderLayout.CENTER);

            JButton editButton = new JButton("Sửa tin đã chọn");
            LoginWindow.styleButton(editButton, true);
            editButton.setEnabled(false);
            table.getSelectionModel().addListSelectionListener(event -> {
                if (!event.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                    int selected = table.convertRowIndexToModel(table.getSelectedRow());
                    editButton.setEnabled(results.get(selected).getSenderId() == userId);
                }
            });

            editButton.addActionListener(event -> {
                int viewRow = table.getSelectedRow();
                if (viewRow < 0) {
                    return;
                }
                int row = table.convertRowIndexToModel(viewRow);
                Message message = results.get(row);
                String editedContent = JOptionPane.showInputDialog(dialog,
                        "Chỉnh sửa nội dung tin nhắn:", message.getContent());
                if (editedContent == null || editedContent.isBlank()) {
                    return;
                }
                try {
                    session.editMessage(message.getMessageId(), editedContent.trim());
                    dialog.dispose();
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(dialog, "Không gửi được yêu cầu sửa tin: "
                                    + e.getMessage(), "Lỗi kết nối", JOptionPane.ERROR_MESSAGE);
                }
            });

            JButton closeButton = new JButton("Đóng");
            LoginWindow.styleButton(closeButton, false);
            closeButton.addActionListener(event -> dialog.dispose());
            JPanel buttons = new JPanel();
            buttons.setBackground(LoginWindow.SURFACE);
            buttons.add(editButton);
            buttons.add(closeButton);
            dialog.add(buttons, BorderLayout.SOUTH);
            dialog.setSize(780, 420);
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        });
    }

    private void showDisconnected(String message) {
        SwingUtilities.invokeLater(() -> {
            conversationArea.append(message + "\n");
            messageField.setEnabled(false);
            sendButton.setEnabled(false);
        });
    }

    private void sendMessage() {
        String content = messageField.getText().trim();
        if (content.isEmpty()) {
            return;
        }

        try {
            session.sendChat(content);
            messageField.setText("");
        } catch (IOException e) {
            showDisconnected("Không gửi được tin nhắn: " + e.getMessage());
        }
    }

    private void logout() {
        session.close();
        dispose();
        new LoginWindow().setVisible(true);
    }

    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getFullname() {
        return fullname;
    }
}
