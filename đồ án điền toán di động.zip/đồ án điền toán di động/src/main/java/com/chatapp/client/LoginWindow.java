package com.chatapp.client;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class LoginWindow extends JFrame {

    static final Color BACKGROUND = new Color(23, 28, 25);
    static final Color SURFACE = new Color(35, 42, 38);
    static final Color INPUT_BACKGROUND = new Color(47, 57, 51);
    static final Color TEXT_COLOR = new Color(231, 239, 233);
    static final Color MUTED_TEXT = new Color(183, 196, 187);
    static final Color ACCENT = new Color(128, 217, 139);
    static final Color ACCENT_TEXT = new Color(20, 35, 23);
    static final Color BORDER_COLOR = new Color(67, 81, 72);

    static {
        configureTheme();
    }

    private final JTextField usernameField = new JTextField(22);
    private final JPasswordField passwordField = new JPasswordField(22);
    private final JButton loginButton = new JButton("Đăng nhập");
    private final JButton registerButton = new JButton("Tạo tài khoản mới");

    public LoginWindow() {
        this("");
    }

    LoginWindow(String initialUsername) {
        super("Chat Online - Đăng nhập");
        getContentPane().setBackground(BACKGROUND);
        usernameField.setText(initialUsername);
        styleInput(usernameField);
        styleInput(passwordField);
        styleButton(loginButton, true);
        styleButton(registerButton, false);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(420, 300));
        setLayout(new BorderLayout());
        add(createForm(), BorderLayout.CENTER);
        add(createButtons(), BorderLayout.SOUTH);
        getRootPane().setDefaultButton(loginButton);
        pack();
        setLocationRelativeTo(null);

        loginButton.addActionListener(event -> login());
        registerButton.addActionListener(event -> openRegisterWindow());
    }

    private JPanel createForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(SURFACE);
        panel.setBorder(BorderFactory.createEmptyBorder(24, 32, 16, 32));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(8, 6, 8, 6);
        constraints.anchor = GridBagConstraints.WEST;

        JLabel title = new JLabel("Đăng nhập vào phòng chat");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        title.setForeground(ACCENT);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        panel.add(title, constraints);

        constraints.gridwidth = 1;
        constraints.gridy = 1;
        panel.add(createLabel("Tên đăng nhập"), constraints);
        constraints.gridx = 1;
        panel.add(usernameField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(createLabel("Mật khẩu"), constraints);
        constraints.gridx = 1;
        panel.add(passwordField, constraints);
        return panel;
    }

    private JPanel createButtons() {
        JPanel panel = new JPanel();
        panel.setBackground(SURFACE);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 24, 20, 24));
        panel.add(loginButton);
        panel.add(registerButton);
        return panel;
    }

    static void configureTheme() {
        UIManager.put("Panel.background", SURFACE);
        UIManager.put("OptionPane.background", SURFACE);
        UIManager.put("OptionPane.messageForeground", TEXT_COLOR);
        UIManager.put("Button.background", new Color(52, 63, 56));
        UIManager.put("Button.foreground", TEXT_COLOR);
        UIManager.put("TextField.background", INPUT_BACKGROUND);
        UIManager.put("TextField.foreground", TEXT_COLOR);
        UIManager.put("PasswordField.background", INPUT_BACKGROUND);
    }

    static void styleInput(JTextField field) {
        field.setBackground(INPUT_BACKGROUND);
        field.setForeground(TEXT_COLOR);
        field.setCaretColor(ACCENT);
        field.setSelectionColor(new Color(70, 115, 78));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR),
                BorderFactory.createEmptyBorder(7, 9, 7, 9)));
    }

    static void styleButton(JButton button, boolean primary) {
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setFocusPainted(false);
        button.setBackground(primary ? ACCENT : new Color(52, 63, 56));
        button.setForeground(primary ? ACCENT_TEXT : TEXT_COLOR);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? ACCENT : BORDER_COLOR),
                BorderFactory.createEmptyBorder(8, 14, 8, 14)));
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(MUTED_TEXT);
        return label;
    }

    private void login() {
        String username = usernameField.getText().trim();
        char[] password = passwordField.getPassword();
        if (username.isEmpty() || password.length == 0) {
            java.util.Arrays.fill(password, '\0');
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập tên đăng nhập và mật khẩu.",
                    "Thiếu thông tin", JOptionPane.WARNING_MESSAGE);
            return;
        }

        setBusy(true);
        new SwingWorker<ServerConnection.ClientSession, Void>() {
            @Override
            protected ServerConnection.ClientSession doInBackground() throws IOException {
                try {
                    return ServerConnection.connectAndLogin(username, password);
                } finally {
                    java.util.Arrays.fill(password, '\0');
                }
            }

            @Override
            protected void done() {
                setBusy(false);
                ServerConnection.ClientSession session = null;
                try {
                    session = get();
                    String[] response = session.initialResponse().split("\\|", -1);
                    if (response.length == 2 && "ERR".equals(response[0])) {
                        showServerError(response[1]);
                        session.close();
                        return;
                    }
                    if (response.length != 5 || !"OK".equals(response[0])
                            || !"LOGIN".equals(response[1])) {
                        showServerError(null);
                        session.close();
                        return;
                    }

                    int userId = Integer.parseInt(response[2]);
                    String loggedInUsername = ServerConnection.decodeField(response[3]);
                    String fullname = ServerConnection.decodeField(response[4]);
                    dispose();
                    new ChatWindow(userId, loggedInUsername, fullname, session).setVisible(true);
                } catch (Exception e) {
                    if (session != null) {
                        session.close();
                    }
                    showConnectionError(e);
                }
            }
        }.execute();
    }

    private void showServerError(String encodedMessage) {
        String message = encodedMessage == null
                ? "Phản hồi từ server không đúng định dạng."
                : ServerConnection.decodeField(encodedMessage);
        JOptionPane.showMessageDialog(this, message, "Đăng nhập thất bại",
                JOptionPane.ERROR_MESSAGE);
    }

    private void showConnectionError(Exception error) {
        Throwable cause = error.getCause() == null ? error : error.getCause();
        JOptionPane.showMessageDialog(this,
                "Không thể xử lý đăng nhập: " + cause.getMessage()
                        + "\nHãy kiểm tra ChatServer đang chạy ở cổng 5000.",
                "Lỗi kết nối", JOptionPane.ERROR_MESSAGE);
    }

    private void setBusy(boolean busy) {
        loginButton.setEnabled(!busy);
        registerButton.setEnabled(!busy);
        usernameField.setEnabled(!busy);
        passwordField.setEnabled(!busy);
    }

    private void openRegisterWindow() {
        dispose();
        new RegisterWindow().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginWindow().setVisible(true));
    }

    /** Shared line-protocol helpers for the login and registration windows. */
    static final class ServerConnection {
        private static final String HOST = "localhost";
        private static final int PORT = 5000;

        private ServerConnection() {
        }

        static ClientSession connectAndLogin(String username, char[] password) throws IOException {
            Socket socket = new Socket();
            try {
                socket.connect(new InetSocketAddress(HOST, PORT), 3_000);
                socket.setSoTimeout(0);

                BufferedReader input = new BufferedReader(new InputStreamReader(
                        socket.getInputStream(), StandardCharsets.UTF_8));
                PrintWriter output = new PrintWriter(new OutputStreamWriter(
                        socket.getOutputStream(), StandardCharsets.UTF_8), true);
                String request = "LOGIN|" + encodeField(username)
                        + "|" + encodeField(new String(password));
                output.println(request);
                String response = input.readLine();
                if (response == null) {
                    throw new IOException("Server da dong ket noi truoc khi tra ket qua.");
                }
                return new ClientSession(socket, input, output, response);
            } catch (IOException | RuntimeException e) {
                try {
                    socket.close();
                } catch (IOException ignored) {
                    // Keep the original connection error.
                }
                throw e;
            }
        }

        static String sendRequest(String request) throws IOException {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(HOST, PORT), 3_000);
                socket.setSoTimeout(5_000);

                try (PrintWriter output = new PrintWriter(new OutputStreamWriter(
                             socket.getOutputStream(), StandardCharsets.UTF_8), true);
                     BufferedReader input = new BufferedReader(new InputStreamReader(
                             socket.getInputStream(), StandardCharsets.UTF_8))) {
                    output.println(request);
                    String response = input.readLine();
                    if (response == null) {
                        throw new IOException("Server da dong ket noi truoc khi tra ket qua.");
                    }
                    return response;
                }
            }
        }

        static String encodeField(String value) {
            return Base64.getUrlEncoder().withoutPadding()
                    .encodeToString(value.getBytes(StandardCharsets.UTF_8));
        }

        static String decodeField(String value) {
            return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8);
        }

        static final class ClientSession implements AutoCloseable {
            private final Socket socket;
            private final BufferedReader input;
            private final PrintWriter output;
            private final String initialResponse;

            private ClientSession(Socket socket, BufferedReader input,
                                 PrintWriter output, String initialResponse) {
                this.socket = socket;
                this.input = input;
                this.output = output;
                this.initialResponse = initialResponse;
            }

            String initialResponse() {
                return initialResponse;
            }

            String readLine() throws IOException {
                return input.readLine();
            }

            synchronized void sendChat(String content) throws IOException {
                sendCommand("CHAT|" + encodeField(content));
            }

            synchronized void searchMessages(String query) throws IOException {
                sendCommand("SEARCH|" + encodeField(query));
            }

            synchronized void editMessage(int messageId, String content) throws IOException {
                sendCommand("EDIT|" + messageId + "|" + encodeField(content));
            }

            private void sendCommand(String command) throws IOException {
                output.println(command);
                if (output.checkError()) {
                    throw new IOException("Khong gui duoc yeu cau den server.");
                }
            }

            @Override
            public void close() {
                try {
                    socket.close();
                } catch (IOException ignored) {
                    // The client is closing this session anyway.
                }
            }
        }
    }
}
