package com.chatapp.client;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;

public class RegisterWindow extends JFrame {

    private final JTextField fullnameField = new JTextField(22);
    private final JTextField usernameField = new JTextField(22);
    private final JPasswordField passwordField = new JPasswordField(22);
    private final JButton registerButton = new JButton("Đăng ký");
    private final JButton backButton = new JButton("Quay lại đăng nhập");

    public RegisterWindow() {
        super("Chat Online - Đăng ký");
        LoginWindow.configureTheme();
        getContentPane().setBackground(LoginWindow.BACKGROUND);
        LoginWindow.styleInput(fullnameField);
        LoginWindow.styleInput(usernameField);
        LoginWindow.styleInput(passwordField);
        LoginWindow.styleButton(registerButton, true);
        LoginWindow.styleButton(backButton, false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(440, 340));
        setLayout(new BorderLayout());
        add(createForm(), BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        buttons.setBackground(LoginWindow.SURFACE);
        buttons.setBorder(BorderFactory.createEmptyBorder(0, 24, 20, 24));
        buttons.add(registerButton);
        buttons.add(backButton);
        add(buttons, BorderLayout.SOUTH);

        getRootPane().setDefaultButton(registerButton);
        pack();
        setLocationRelativeTo(null);

        registerButton.addActionListener(event -> register());
        backButton.addActionListener(event -> backToLogin());
    }

    private JPanel createForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(LoginWindow.SURFACE);
        panel.setBorder(BorderFactory.createEmptyBorder(24, 32, 16, 32));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(8, 6, 8, 6);
        constraints.anchor = GridBagConstraints.WEST;

        JLabel title = new JLabel("Tạo tài khoản mới");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        title.setForeground(LoginWindow.ACCENT);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        panel.add(title, constraints);

        constraints.gridwidth = 1;
        constraints.gridy = 1;
        panel.add(createLabel("Họ tên"), constraints);
        constraints.gridx = 1;
        panel.add(fullnameField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(createLabel("Tên đăng nhập"), constraints);
        constraints.gridx = 1;
        panel.add(usernameField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        panel.add(createLabel("Mật khẩu (ít nhất 8 ký tự)"), constraints);
        constraints.gridx = 1;
        panel.add(passwordField, constraints);
        return panel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(LoginWindow.MUTED_TEXT);
        return label;
    }

    private void register() {
        String fullname = fullnameField.getText().trim();
        String username = usernameField.getText().trim();
        char[] password = passwordField.getPassword();

        if (fullname.isEmpty() || username.isEmpty() || password.length < 8) {
            java.util.Arrays.fill(password, '\0');
            JOptionPane.showMessageDialog(this,
                    "Nhập họ tên, tên đăng nhập và mật khẩu có ít nhất 8 ký tự.",
                    "Thông tin chưa hợp lệ", JOptionPane.WARNING_MESSAGE);
            return;
        }

        setBusy(true);
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws IOException {
                try {
                    String request = "REGISTER|"
                            + LoginWindow.ServerConnection.encodeField(username) + "|"
                            + LoginWindow.ServerConnection.encodeField(new String(password)) + "|"
                            + LoginWindow.ServerConnection.encodeField(fullname);
                    return LoginWindow.ServerConnection.sendRequest(request);
                } finally {
                    java.util.Arrays.fill(password, '\0');
                }
            }

            @Override
            protected void done() {
                setBusy(false);
                try {
                    String[] response = get().split("\\|", -1);
                    if (response.length == 2 && "ERR".equals(response[0])) {
                        showServerError(response[1]);
                        return;
                    }
                    if (response.length != 5 || !"OK".equals(response[0])
                            || !"REGISTERED".equals(response[1])) {
                        showServerError(null);
                        return;
                    }

                    JOptionPane.showMessageDialog(RegisterWindow.this,
                            "Đăng ký thành công. Bây giờ bạn có thể đăng nhập.",
                            "Hoàn tất", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    new LoginWindow(username).setVisible(true);
                } catch (Exception e) {
                    showConnectionError(e);
                }
            }
        }.execute();
    }

    private void showServerError(String encodedMessage) {
        String message = encodedMessage == null
                ? "Phản hồi từ server không đúng định dạng."
                : LoginWindow.ServerConnection.decodeField(encodedMessage);
        JOptionPane.showMessageDialog(this, message, "Đăng ký thất bại",
                JOptionPane.ERROR_MESSAGE);
    }

    private void showConnectionError(Exception error) {
        Throwable cause = error.getCause() == null ? error : error.getCause();
        JOptionPane.showMessageDialog(this,
                "Không thể xử lý đăng ký: " + cause.getMessage()
                        + "\nHãy kiểm tra ChatServer đang chạy ở cổng 5000.",
                "Lỗi kết nối", JOptionPane.ERROR_MESSAGE);
    }

    private void setBusy(boolean busy) {
        registerButton.setEnabled(!busy);
        backButton.setEnabled(!busy);
        fullnameField.setEnabled(!busy);
        usernameField.setEnabled(!busy);
        passwordField.setEnabled(!busy);
    }

    private void backToLogin() {
        dispose();
        new LoginWindow().setVisible(true);
    }
}
