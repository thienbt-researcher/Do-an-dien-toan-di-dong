
package com.chatapp.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    
private static final String URL =
        "jdbc:mysql://localhost:3306/chat_online?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Ho_Chi_Minh";
        

    private static final String USER = "root";

    private static final String PASSWORD = "";

    public static Connection getConnection() {

        try {
            Connection connection = DriverManager.getConnection(
                    URL, USER, PASSWORD
            );

            return connection;

        } catch (SQLException e) {
            System.out.println("Ket noi MySQL that bai!");
            e.printStackTrace();
            return null;
        }
    }
}
